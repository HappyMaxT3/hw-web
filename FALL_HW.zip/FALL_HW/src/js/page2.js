let whatYear = document.querySelector('#whatYear');


let descriptionStudy = document.querySelector('#descriptionStudy');

// let descriptionStudy2 = document.querySelector('#descriptionStudy2');
// let descriptionStudy3 = document.querySelector('#descriptionStudy3');


whatYear.addEventListener('change', function () {
    const selectedRadio = whatYear.querySelector('input[name="whatYear"]:checked');
  
    if (selectedRadio.value == "c_1") {
        descriptionStudy.textContent = "1 курс";
    } else if (selectedRadio.value == "c_2") {
        descriptionStudy.textContent = "2 курс";
    } else if (selectedRadio.value == "c_3") {
        descriptionStudy.textContent = "3 курс";
    } else if (selectedRadio.value == "c_4") {
        descriptionStudy.textContent = "4 курс";
    } else if (selectedRadio.value == "c_5") {
        descriptionStudy.textContent = "5 курс";
    } else if (selectedRadio.value == "c_6") {
        descriptionStudy.textContent = "6 курс";
    } else if (selectedRadio.value == "graduate") {
        descriptionStudy.textContent = "Закончил Вышку";
    }
  });




//   let descriptionStudy1 = document.querySelector('#descriptionStudy1');
//   let ed_ = document.querySelector('#ed_');


//   ed_.addEventListener('change', function () {
//     const selectedRadio = whatYear.querySelector('input[name="ed_"]:checked');
  
//     if (selectedRadio.value == "ed_1") {
//         descriptionStudy1.textContent = "бакалавриат";
//     } else if (selectedRadio.value == "ed_2") {
//         descriptionStudy1.textContent = "магистратура";
//     } else if (selectedRadio.value == "специалитет") {
//         descriptionStudy1.textContent = "3 курс";
//     } 
//   });






  let work = document.querySelector('#work');
  let work_input = document.querySelector('#work_input');

  work.addEventListener('input', function(){
    work_input.textContent = work.value;
  });