let name = document.querySelector('#name');
let date = document.querySelector('#date');
let bio = document.querySelector('#bio');
let tg = document.querySelector('#tg');
let phone = document.querySelector('#phone');

let descriptionName = document.querySelector('#descriptionName');
let descriptionAge = document.querySelector('#descriptionAge');
let bio_input = document.querySelector('#bio_input');
let tg_input = document.querySelector('#tg_input');
let phone_input = document.querySelector('#phone_input');


phone.addEventListener('input', function(){
  phone_input.textContent = phone.value; 
}
);


tg.addEventListener('input', function(){
  tg_input.textContent = tg.value;
});

name.addEventListener('input', function() {
    descriptionName.textContent = name.value;
});

bio.addEventListener('input', function() {
  bio_input.textContent = bio.value;
});


const form = document.querySelector('#gender-form');
const fieldGender = document.querySelector('#gender-field');

form.addEventListener('change', function () {
  const selectedOption = form.querySelector('input[name="option"]:checked');

  if (selectedOption.value == "male") {
    fieldGender.textContent = "Паренек";
  } else if (selectedOption.value == "female") {
    fieldGender.textContent = "Девчуля";
  }
});




date.addEventListener('input', function() {
    var str = date.value;
    var newstr = str.replace(".", "/");
    var n = newstr.replace(".", "/");
    const bluat = n[3]+n[4]+n[2]+n[0]+n[1]+n.slice(5)
    const inputDate = new Date(bluat);
    var ageDifMs = Date.now() - inputDate;
    var ageDate = new Date(ageDifMs);
    var age = Math.abs(ageDate.getUTCFullYear() - 1970);
    descriptionAge.textContent = age;
});







